-- SoloSquadScripts
fx_version 'bodacious'
games { 'gta5' }
lua54 'yes'
author 'SoloSquadScripts'
description 'TakeHostage'
version '1.2.0'

client_script "cl_takehostage.lua"
server_script "sv_takehostage.lua"
