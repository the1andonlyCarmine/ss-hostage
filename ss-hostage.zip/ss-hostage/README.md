# Take Hostage by the1andonly_carmine and SoloSquadScripts

Instructions on how to use:
Type /takehostage, a valid weapon is needed(Add or remove weapons in cl_takehostage.lua)
Then press G to release the hostage or H to kill the hostage!

Feel free to make improvements with PRs
